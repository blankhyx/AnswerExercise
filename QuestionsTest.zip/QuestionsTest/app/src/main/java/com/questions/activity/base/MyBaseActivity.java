package com.questions.activity.base;

import android.databinding.ViewDataBinding;

/**
 * Created by 11470 on 2017/10/23.
 */

public abstract class MyBaseActivity<V extends ViewDataBinding> extends BaseActivity<V> {



}
